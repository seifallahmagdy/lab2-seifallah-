# Lab 2 – Portfolio Website

Personal portfolio website created for **Lab 2**.

## Technologies
- HTML5
- CSS3

## Sections
- Header and navigation
- About Me
- Projects
- Contact form
- Footer

## Projects
1. Car Rental System
2. Car Price Predictor

## Run locally
Open `index.html` in any modern web browser.

## GitHub Pages
After uploading this repository to GitHub:
1. Open the repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`.
5. Save.

GitHub will provide the published website URL.

## Student
Seifallah Magdy
